﻿# -*- coding: utf-8 -*-
__all__ = ["wiki", "api", "page", "category", "user", "pagelist", "wikifile"]
from wiki import *
from api import *
from page import *
from category import *
from user import *
from wikifile import *
